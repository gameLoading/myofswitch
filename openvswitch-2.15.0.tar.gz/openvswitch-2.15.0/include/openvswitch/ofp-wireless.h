#include "wdev.h"
#include "myuci.h"
#include "myubus.h"
#include "myiw.h"

typedef uint8_t ofp_wparams_t;


struct ofp13_wparams_stats_request {
    uint8_t wparamsType;        
    char name[MAX_DEVICE_NAME_LEN];
};

enum wparams_types{
    DEVICES,
    INFO,
    ASSOICATED
};

static enum ofperr handle_wparams_request(struct ofconn* ofconn, const struct ofp_header* oh)
enum ofperr handle_wparams_devices_request(const struct ofp_header *request);
enum ofperr handle_wparams_info_request(const struct ofp_header *request, char *deviceName);
enum ofperr handle_wparams_associcated_request(const struct ofp_header *request, char *deviceName);
ofputil_decode_wparams_stats_request(const struct ofp_header *request,
                                     ofp_wparams_t* type, char *deviceName);