#include <stdint.h>
#include <syslog.h>
#include <config.h>
#include <stdint.h>
#include "openvswitch/ofp-port.h"
#include "openflow/intel-ext.h"
#include "openvswitch/ofp-errors.h"
#include "openvswitch/ofp-msgs.h"
#include "openvswitch/ofp-print.h"
#include "openvswitch/ofp-prop.h"
#include "openvswitch/ofpbuf.h"
#include "openvswitch/vlog.h"


typedef uint8_t ofp_wparams_t;


struct ofp13_wparams_stats_request {
    uint8_t wparamsType;        
    char name[MAX_DEVICE_NAME_LEN];
};

enum wparams_types{
    DEVICES,
    INFO,
    ASSOICATED
};

struct ofconn;

// static enum ofperr handle_wparams_request(struct ofconn* ofconn, const struct ofp_header* oh);

enum ofperr ofputil_decode_wparams_stats_request(const struct ofp_header *request, ofp_wparams_t* type, char *deviceName);

